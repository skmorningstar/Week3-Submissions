a=input()
b=input()
if len(a)==len(b):
    sum=0
    for i in range(0,len(a)):
        if ord(a[i])>ord(b[i]):
            sum=1
    if sum==1:
        print("NO")
    elif sum==0:
        print("YES")
else:
    print("NO")
