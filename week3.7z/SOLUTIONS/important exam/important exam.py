n,m=map(int,input().split())
l=[]
for i in range(n):
    l.append(input())
freq=[]
for i in range(m):
    a=0
    b=0
    c=0
    d=0
    e=0
    for j in range(n):
        if l[j][i]=="A":
            a=a+1
        elif l[j][i]=="B":
            b=b+1
        elif l[j][i]=="C":
            c=c+1
        elif l[j][i]=="D":
            d=d+1
        elif l[j][i]=="E":
            e=e+1
    freq.append(max(a,b,c,d,e))
num=input().split()
sum=0
for i in range(m):
    sum=sum+int(num[i])*(freq[i])
print(sum)
    
        
