t=int(input())
for i in range(t):
    n=int(input())
    s=input()
    if ("1"*n) in s:
        print(n*"1")
    else:
        print(n*"0")
