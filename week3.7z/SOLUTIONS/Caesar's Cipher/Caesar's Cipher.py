q=int(input())
for i in range(q):
    s=input()
    t=input()
    sum=0
    if len(s)!=len(t):
        print(-1)
    else:
        if (ord(t[0])-ord(s[0]))>=0:
                k=ord(t[0])-ord(s[0])
        else:
                k=26+(ord(t[0])-ord(s[0]))
        for j in range(len(s)):
            if (ord(t[j])-ord(s[j]))>=0:
                z=ord(t[j])-ord(s[j])
            else:
                z=26+(ord(t[j])-ord(s[j]))
            if z!=k:
                sum=1
        if sum==0:
            print(k)
        else:
            print(-1)
